## 3D Test

A [Seika Engine](https://github.com/Chukobyte/seika-engine) project used to test 3D features.
